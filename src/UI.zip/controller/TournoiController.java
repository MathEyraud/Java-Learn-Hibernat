package com.mycompany.tennis.controller;

import java.util.Scanner;

import com.mycompany.tennis.core.dto.TournoiDTO;
import com.mycompany.tennis.core.service.TournoiService;

/**
 * UN CONTROLLER NE DOIT JAMAIS INTERAGIR AVEC DES ENTITY
 * MAIS DES DTO
 */
public class TournoiController {
	
	/** 
	 * ATTRIBUTS
	 */
	private TournoiService tournoiService;
	
	/** 
	 * CONSTRUCTEUR
	 */
	public TournoiController() {
		this.tournoiService = new TournoiService();
	}
	
	/** 
	 * METHODES
	 */
	// Méthode pour afficher un tournoi à partir de son ID
	public void displayDetailTournoiById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du tournoi dont vous voulez afficher les informations ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idTournoi = scanner.nextLong();
			
			// Affichage du tournoi
			TournoiDTO tournoi = tournoiService.getTournoiById(idTournoi);
			
			if(tournoi == null) {
				System.out.println("Aucun tournoi trouvé !");
				
			}else {
				System.out.println(tournoi);
			}
			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations du tournoi : " + e.getMessage());
			e.printStackTrace();
		}
	}
	public void createTournoi() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {

			// Demander le nom du tournoi
	        System.out.println("Veuillez saisir le nom du tournoi :");
			
			// Récupérer le nom du tournoi
	        String nom = scanner.nextLine();
			
			// Demander le code du tournoi
	        System.out.println("Veuillez saisir le code du tournoi :");
	
			// Récupérer le code du tournoi
	        String code = scanner.nextLine();
			
			// Créer un nouveau tournoi
	        TournoiDTO newTournoi = new TournoiDTO(nom, code);
			
			//Envoyer le nouveau tournoi vers la DB
	        tournoiService.createTournoi(newTournoi);
			
	        System.out.println("Le tournoi a été créé avec succès !");
	     
        // Gestion des erreurs
 		} catch (Exception e) {
 			System.out.println("Une erreur s'est produite lors de l'affichage des informations de l'épreuve : " + e.getMessage());
 			e.printStackTrace();
 		}

	}
	//TODO : A faire
	public void updateNomTournoi() {
        
	}
	//TODO : A faire
	public void deleteTournoi() {
		
	}
}
