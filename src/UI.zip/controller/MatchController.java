package com.mycompany.tennis.controller;

import java.util.Scanner;

import com.mycompany.tennis.core.dto.EpreuveFullDTO;
import com.mycompany.tennis.core.dto.JoueurDTO;
import com.mycompany.tennis.core.dto.MatchDTO;
import com.mycompany.tennis.core.dto.ScoreDTO;
import com.mycompany.tennis.core.service.EpreuveService;
import com.mycompany.tennis.core.service.JoueurService;
import com.mycompany.tennis.core.service.MatchService;

/**
 * UN CONTROLLER NE DOIT JAMAIS INTERAGIR AVEC DES ENTITY
 * MAIS DES DTO
 */
public class MatchController {
	
	/** 
	 * ATTRIBUTS
	 */
	private MatchService 	matchService;
	private EpreuveService 	epreuveService;
	private JoueurService 	joueurService;
	
	/** 
	 * CONSTRUCTEUR
	 */
	public MatchController() {
		this.matchService	= new MatchService();
		this.epreuveService = new EpreuveService();
		this.joueurService 	= new JoueurService();
	}
	
	/** 
	 * METHODES
	 */
	// Méthode pour afficher un tournoi à partir de son ID
	public void displayDetailMatchById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du match dont vous voulez afficher les informations ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idMatch= scanner.nextLong();
			
			// Affichage du tournoi
			MatchDTO match = matchService.getMatchById(idMatch);
			
			if(match == null) {
				System.out.println("Aucun tournoi trouvé !");
				
			}else {
				System.out.println(match);
			}
			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations du match : " + e.getMessage());
			e.printStackTrace();
		}
	}
	public void declareMatchGreenById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du match dont vous voulez déclarer un dopage ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idMatch= scanner.nextLong();
			
			// Modification des données
			matchService.tapisVert(idMatch);
			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage de la modification du match : " + e.getMessage());
			e.printStackTrace();
		}
	}
	public void createMatch() {
		
		try (Scanner scanner = new Scanner(System.in)) {
			
			// Demander l'ID de l'épreuve
	        System.out.println("Veuillez saisir l'ID de l'épreuve :");
	        
		    // Validation de l'entrée utilisateur
 			if (!scanner.hasNextLong()) {
 				System.out.println("Veuillez saisir un identifiant valide !");
 				return;
 				
 			}	Long idEpreuve = scanner.nextLong();
 			
			
 			// Demander l'ID du joueur vainqueur
	        System.out.println("Veuillez saisir l'ID du joueur vainqueur :");
	        
 			// Validation de l'entrée utilisateur
 			if (!scanner.hasNextLong()) {
 				System.out.println("Veuillez saisir un identifiant valide !");
 				return;
 				
 			}	Long idVainqueur = scanner.nextLong();
	        
	        // Demander l'ID du joueur finaliste (perdant)
	        System.out.println("Veuillez saisir l'ID du joueur finaliste (perdant) :");
	        
	        // Validation de l'entrée utilisateur
 			if (!scanner.hasNextLong()) {
 				System.out.println("Veuillez saisir un identifiant valide !");
 				return;
 				
 			}	Long idFinaliste= scanner.nextLong();
 			
 			// Demander le résultat du match
	        System.out.println("Veuillez saisir les sets du joueur vainqueur :");
	        
	        System.out.println("Set 1 :");
	        // Validation de l'entrée utilisateur
 			if (!scanner.hasNextByte()) {
 				System.out.println("Veuillez saisir une valeur valide !");
 				return;
 				
 			}	Byte set1= scanner.nextByte();
 			
 			System.out.println("Set 2 :");
	        // Validation de l'entrée utilisateur
 			if (!scanner.hasNextByte()) {
 				System.out.println("Veuillez saisir une valeur valide !");
 				return;
 				
 			}	Byte set2= scanner.nextByte();
 			
 			System.out.println("Set 3 :");
	        // Validation de l'entrée utilisateur
 			if (!scanner.hasNextByte()) {
 				System.out.println("Veuillez saisir une valeur valide !");
 				return;
 				
 			}	Byte set3= scanner.nextByte();
 			
 			System.out.println("Set 4 :");
	        // Validation de l'entrée utilisateur
 			if (!scanner.hasNextByte()) {
 				System.out.println("Veuillez saisir une valeur valide !");
 				return;
 				
 			}	Byte set4= scanner.nextByte();
 			
 			System.out.println("Set 5 :");
	        // Validation de l'entrée utilisateur
 			if (!scanner.hasNextByte()) {
 				System.out.println("Veuillez saisir une valeur valide !");
 				return;
 				
 			}	Byte set5= scanner.nextByte();
 			
 			// Création des entités
 			EpreuveFullDTO 	epreuveDTO 		= epreuveService.getEpreuveByIdWithDetails(idEpreuve);
 			JoueurDTO 		vainqueurDTO 	= joueurService.getJoueurById(idVainqueur);
 			JoueurDTO 		finalisteDTO 	= joueurService.getJoueurById(idFinaliste);
 			ScoreDTO 		scoreDTO 		= new ScoreDTO(set1,set2,set3,set4,set5);
 			
 			// Création et envoi du match
 			MatchDTO newMatch = new MatchDTO(epreuveDTO, vainqueurDTO, finalisteDTO, scoreDTO);
 			matchService.createMatch(newMatch);
 			
	        //Affichage du succès
	        System.out.println("Le match a été créé avec succès !");

	    // Gestion des erreurs
 		} catch (Exception e) {
 			System.out.println("Une erreur s'est produite lors de la création du joueur : " + e.getMessage());
 			e.printStackTrace();
 		}
	}
	public void deleteMatchById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du match que vous voulez supprimer ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idMatch= scanner.nextLong();
			
			// Affichage du tournoi
			matchService.deleteMatch(idMatch);
			
			System.out.println("Le match a bien été supprimé avec succès !");			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de la suppression du match : " + e.getMessage());
			e.printStackTrace();
		}
	}
}
