package com.mycompany.tennis.controller;

import java.util.Scanner;

import com.mycompany.tennis.core.service.ScoreService;

public class ScoreController {
	
	/** 
	 * ATTRIBUTS
	 */
	private ScoreService scoreService;
	
	/** 
	 * CONSTRUCTEUR
	 */
	public ScoreController() {
		this.scoreService	= new ScoreService();
	}
	
	/** 
	 * METHODES
	 */
	public void deleteScoreById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du score que vous voulez supprimer ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idScore = scanner.nextLong();
			
			// Affichage du tournoi
			scoreService.deleteScoreById(idScore);
			
			System.out.println("Le score a bien été supprimé avec succès !");			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de la suppression du score : " + e.getMessage());
			e.printStackTrace();
		}
	}
}
