package com.mycompany.tennis.controller;

import java.util.List;
import java.util.Scanner;

import com.mycompany.tennis.core.dto.JoueurDTO;
import com.mycompany.tennis.core.service.JoueurService;

/**
 * UN CONTROLLER NE DOIT JAMAIS INTERAGIR AVEC DES ENTITY
 * MAIS DES DTO
 */
public class JoueurController {
	
	/** 
	 * ATTRIBUTS
	 */
	private JoueurService joueurService;
	
	/** 
	 * CONSTRUCTEUR
	 */
	public JoueurController() {
		this.joueurService = new JoueurService();
	}
	
	/** 
	 * METHODES
	 */
	// Méthode pour afficher un joueur à partir de son ID
	public void displayDetailJoueurById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du joueur dont vous voulez afficher les informations ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide.");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idJoueur = scanner.nextLong();
			
			// Affichage du joueur
			JoueurDTO joueur = joueurService.getJoueurById(idJoueur);
			if(joueur == null) {
				System.out.println("Aucun joueur trouvé !");
			}else {
				System.out.println(joueur);
			}
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations du joueur : " + e.getMessage());
			e.printStackTrace();
		}
	}
	// Méthode avec HQL
	public void displayJoueurs() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try {
	        // Récupération de la liste des joueurs depuis le service
	        List<JoueurDTO> joueurs = joueurService.getJoueurs();
	        
	        // Vérification si la liste des joueurs est vide
	        if (joueurs.isEmpty()) {
	            // Affichage d'un message si aucun joueur n'a été trouvé
	            System.out.println("Aucun joueur trouvé !");
	        } else {
	            // Affichage d'un message indiquant que la liste des joueurs est affichée
	            System.out.println("Liste des joueurs :");
	            // Parcours de la liste des joueurs et affichage de chaque joueur
	            for (JoueurDTO joueur : joueurs) {
	                System.out.println(joueur);
	            }
	        }
	    } catch (Exception e) {
	        // Gestion des erreurs en affichant un message d'erreur et la trace de la pile
	        System.out.println("Une erreur s'est produite lors de l'affichage des informations des joueurs : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	// Méthode avec HQL
	public void displayJoueursBySexe() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est le sexe des joueurs que vous voulez afficher (H ou F) ?");
			char sexe = scanner.nextLine().charAt(0);
			
			// Vérification du sexe saisi
			if (sexe == 'h') {
				sexe = 'H';
			}else if(sexe == 'f') {
				sexe = 'F';
			}
			
			if (sexe != 'H' && sexe != 'F') {
			    System.out.println("Le sexe doit être H ou F.");
			    return;
			}
			
			// Affichage des joueurs par sexe
			List<JoueurDTO> joueurs = joueurService.getJoueursBySexe(sexe);
			
			if (joueurs.isEmpty()) {
				System.out.println("Aucun joueur trouvé pour le sexe " + sexe + ".");
			} else {
				System.out.println("Joueurs de sexe " + sexe + ":");
				for (JoueurDTO joueur : joueurs) {
					System.out.println(joueur);
				}
			}
			
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations des joueurs : " + e.getMessage());
			e.printStackTrace();
		}
	}
	// Cette fonction permet de créer un joueur en demandant à l'utilisateur de saisir le nom, prénom et sexe du joueur
	public void createJoueur() {
		
		try (Scanner scanner = new Scanner(System.in)) {
			
	        // Demander le nom du joueur
	        System.out.println("Veuillez saisir le nom du joueur :");
	        // Récupérer le nom du joueur
	        String nom = scanner.nextLine();
	        
	        // Demander le prénom du joueur
	        System.out.println("Veuillez saisir le prénom du joueur :");
	        // Récupérer le prénom du joueur
	        String prenom = scanner.nextLine();
	        
	        // Demander le sexe du joueur
	        System.out.println("Veuillez saisir le sexe du joueur (H/F) :");
	        // Récupérer le sexe du joueur
	        String sexe = scanner.next();
	        
	        // Vérifier si le sexe saisi est valide
	        if (sexe.equals("h")) {
	            sexe = "H";
	        } else if (sexe.equals("f")) {
	            sexe = "F";
	        }
	        if (!sexe.equals("H") && !sexe.equals("F")) {
	            System.out.println("Le sexe doit être 'H' ou 'F'.");
	            return;
	        }
	        
	        // Créer un nouveau joueur avec les informations saisies
	        JoueurDTO newJoueur = new JoueurDTO(nom, prenom, sexe);
	        
	        // Envoyer le nouveau joueur vers la base de données via le service
	        joueurService.createJoueur(newJoueur);
	        
	        System.out.println("Le joueur a été créé avec succès !");
	        
	    } catch (Exception e) {
	        // Gestion des erreurs en affichant un message d'erreur et la trace de la pile
	        System.out.println("Une erreur s'est produite lors de la création du joueur : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	// Cette fonction permet de mettre à jour le nom d'un joueur en demandant à l'utilisateur de saisir le nouveau nom
	public void updateNomJoueur() {
		
	    try (Scanner scanner = new Scanner(System.in)) {
	    	
	        // Demander l'id du joueur à modifier
	        System.out.println("Veuillez saisir l'id du joueur à modifier :");
	        // Récupérer l'id saisie du joueur
	        Long idJoueur = scanner.nextLong();
	        scanner.nextLine();
	        
	        // Demander le nouveau nom du joueur
	        System.out.println("Veuillez saisir le nouveau nom du joueur :");
	        // Récupérer le nouveau nom du joueur
	        String newNom = scanner.nextLine();
	        
	        // Modifier le joueur dans la base de données via le service
	        joueurService.updateNomJoueur(idJoueur, newNom);
	        
	    } catch (Exception e) {
	        // Gestion des erreurs en affichant un message d'erreur et la trace de la pile
	        System.out.println("Une erreur s'est produite lors de la mise à jour du nom du joueur : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	// Cette fonction permet de supprimer un joueur en demandant à l'utilisateur de saisir l'id du joueur à supprimer
	public void deleteJoueur() {
		
	    try (Scanner scanner = new Scanner(System.in)) {
	    	
	        // Demander l'id du joueur à supprimer
	        System.out.println("Veuillez saisir l'id du joueur à supprimer :");
	        
	        // Récupérer l'id saisie du joueur
	        Long idJoueur = scanner.nextLong();
	        scanner.nextLine();
	        
	        // Supprimer le joueur dans la base de données via le service
	        joueurService.deleteJoueur(idJoueur);
	        
	    } catch (Exception e) {
	        // Gestion des erreurs en affichant un message d'erreur et la trace de la pile
	        System.out.println("Une erreur s'est produite lors de la suppression du joueur : " + e.getMessage());
	        e.printStackTrace();
	    }
	}
}
