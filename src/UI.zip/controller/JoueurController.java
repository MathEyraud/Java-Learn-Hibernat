package com.mycompany.tennis.controller;

import java.util.Scanner;

import com.mycompany.tennis.core.dto.JoueurDTO;
import com.mycompany.tennis.core.service.JoueurService;

/**
 * UN CONTROLLER NE DOIT JAMAIS INTERAGIR AVEC DES ENTITY
 * MAIS DES DTO
 */
public class JoueurController {
	
	/** 
	 * ATTRIBUTS
	 */
	private JoueurService joueurService;
	
	/** 
	 * CONSTRUCTEUR
	 */
	public JoueurController() {
		this.joueurService = new JoueurService();
	}
	
	/** 
	 * METHODES
	 */
	// Méthode pour afficher un joueur à partir de son ID
	public void displayDetailJoueurById() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant du joueur dont vous voulez afficher les informations ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide.");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idJoueur = scanner.nextLong();
			
			// Affichage du joueur
			JoueurDTO joueur = joueurService.getJoueurById(idJoueur);
			if(joueur == null) {
				System.out.println("Aucun joueur trouvé !");
			}else {
				System.out.println(joueur);
			}
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations du joueur : " + e.getMessage());
			e.printStackTrace();
		}
	}
	// TODO : FAIRE LA GESTION DES ERREURS DE SAISIES
	public void createJoueur() {
		
		try (Scanner scanner = new Scanner(System.in)) {
		
			// Demander le nom du joueur
	        System.out.println("Veuillez saisir le nom du joueur :");
			
			// Récupérer le nom du joueur
	        String nom = scanner.nextLine();
			
			// Demander le prénom du joueur 
	        System.out.println("Veuillez saisir le prénom du joueur :");
	
			// Récupérer le prénom du joueur
	        String prenom = scanner.nextLine();
			
			// Demander le sexe du joueur
	        System.out.println("Veuillez saisir le sexe du joueur (M/F) :");
			
			//Récupérer le sexe du joueur
	        String sexe = scanner.next();
			
			// Créer un nouveau joueur
	        JoueurDTO newJoueur = new JoueurDTO(nom, prenom, sexe);
			
			//Envoyer le nouveau joueur vers la DB
	        joueurService.createJoueur(newJoueur);
			
	        System.out.println("Le joueur a été créé avec succès !");

	    // Gestion des erreurs
 		} catch (Exception e) {
 			System.out.println("Une erreur s'est produite lors de la création du joueur : " + e.getMessage());
 			e.printStackTrace();
 		}

	}
	// TODO : FAIRE LA GESTION DES ERREURS DE SAISIES
	public void updateNomJoueur() {
		
		try (Scanner scanner = new Scanner(System.in)) {

			// Demander l'id du joueur à modifier
	        System.out.println("Veuillez saisir l'id du joueur à modifier :");
			
			// Récupérer l'id saisie du joueur
	        Long idJoueur = scanner.nextLong();
	        scanner.nextLine();
			
			// Demander le nouveau nom du joueur 
	        System.out.println("Veuillez saisir le nouveau nom du joueur :");
	
			// Récupérer le nouveau nom du joueur
	        String newNom = scanner.nextLine();
	        
			//Modifier le joueur dans la DB
	        joueurService.updateNomJoueur(idJoueur, newNom);
        
        // Gestion des erreurs
  		} catch (Exception e) {
  			System.out.println("Une erreur s'est produite lors de la mise à jour du nom du joueur : " + e.getMessage());
  			e.printStackTrace();
  		}
        
	}
	// TODO : FAIRE LA GESTION DES ERREURS DE SAISIES
	public void deleteJoueur() {
		
		try (Scanner scanner = new Scanner(System.in)) {

			// Demander l'id du joueur à modifier
	        System.out.println("Veuillez saisir l'id du joueur à supprimer :");
			
			// Récupérer l'id saisie du joueur
	        Long idJoueur = scanner.nextLong();
	        scanner.nextLine();
			
			//Supprimer le joueur dans la DB
	        joueurService.deleteJoueur(idJoueur);
        
        // Gestion des erreurs
  		} catch (Exception e) {
  			System.out.println("Une erreur s'est produite lors de la suppression du joueur : " + e.getMessage());
  			e.printStackTrace();
  		}
	}
}
