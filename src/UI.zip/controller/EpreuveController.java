package com.mycompany.tennis.controller;

import java.util.Scanner;

import com.mycompany.tennis.core.dto.EpreuveFullDTO;
import com.mycompany.tennis.core.dto.EpreuveLightDTO;
import com.mycompany.tennis.core.service.EpreuveService;

/**
 * UN CONTROLLER NE DOIT JAMAIS INTERAGIR AVEC DES ENTITY
 * MAIS DES DTO
 */
public class EpreuveController {
	
	/** 
	 * ATTRIBUTS
	 */
	private EpreuveService epreuveService;
	
	/** 
	 * CONSTRUCTEUR
	 */
	public EpreuveController() {
		this.epreuveService = new EpreuveService();
	}
	
	/** 
	 * METHODES
	 */
	// Méthode pour afficher une épreuve à partir de son ID avec les détails du tournoi
	public void displayDetailEpreuveByIdWithDetails() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant d'épreuve dont vous voulez afficher les informations ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idEpreuve= scanner.nextLong();
			
			// Affichage du joueur
			EpreuveFullDTO epreuveFullDTO = epreuveService.getEpreuveByIdWithDetails(idEpreuve);
			
			if(epreuveFullDTO == null) {
				System.out.println("Aucune épreuve trouvé !");
				
			}else {
				System.out.print(epreuveFullDTO + " ");
			}
			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations de l'épreuve : " + e.getMessage());
			e.printStackTrace();
		}
	}
	// Méthode pour afficher une épreuve à partir de son ID sans les détails du tournoi
	public void displayDetailEpreuveByIdWithoutDetails() {
		
		// Utilisation de try-with-resources pour la gestion du scanner
		try (Scanner scanner = new Scanner(System.in)) {
			
			System.out.println("Quel est l'identifant d'épreuve dont vous voulez afficher les informations ?");
			
			// Validation de l'entrée utilisateur
			if (!scanner.hasNextLong()) {
				System.out.println("Veuillez saisir un identifiant valide !");
				return;
			}
			
			// Récupération de l'id via la saisie de l'utilisateur
			Long idEpreuve= scanner.nextLong();
			
			// Affichage du joueur
			EpreuveLightDTO epreuveLightDTO = epreuveService.getEpreuveByIdWithoutDetails(idEpreuve);
			
			if(epreuveLightDTO == null) {
				System.out.println("Aucune épreuve trouvé !");
				
			}else {
				System.out.println(epreuveLightDTO);
			}
			
		
		// Gestion des erreurs
		} catch (Exception e) {
			System.out.println("Une erreur s'est produite lors de l'affichage des informations de l'épreuve : " + e.getMessage());
			e.printStackTrace();
		}
	}
	//TODO : A faire createEpreuve
	public void createEpreuve() {
		
	}
	//TODO : A faire updateEpreuve
	public void updateEpreuve() {
        
	}
	//TODO : A deleteEpreuve
	public void deleteEpreuve() {
		
	}
}
