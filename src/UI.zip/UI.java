package com.mycompany.tennis;

import com.mycompany.tennis.controller.EpreuveController;
import com.mycompany.tennis.controller.JoueurController;
import com.mycompany.tennis.controller.MatchController;
import com.mycompany.tennis.controller.ScoreController;

public class UI {
	
	
	public static void main(String... args) {
		
		// Création du controlleur pour tester les échange avec UI
		JoueurController 	joueurController 	= new JoueurController();
		EpreuveController 	epreuveController 	= new EpreuveController();
		MatchController 	matchController 	= new MatchController();
		ScoreController 	scoreController 	= new ScoreController();
		
		// ----------------------------------------- //
		// ----------- CONTROLEUR JOUEUR ----------- //
		// ----------------------------------------- //
		/** Affichage d'un joueur en fonction d'un id
		 * @return : Affichage les informations du joueur dans la console
		 */
		//joueurController.displayDetailJoueurById();
		
		/** Création d'un joueur dans la DB
		 * @return : Affichage des informations du joueur dans la console
		 */
		//joueurController.createJoueur();
		
		/** Modification du nom d'un joueur dans la DB
		 * @return : 
		 */
		//joueurController.updateNomJoueur();
		
		/** Supprimer un joueur dans la DB
		 * @return : 
		 */
		//joueurController.deleteJoueur();
		
		// ------------------------------------------ //
		// ----------- CONTROLEUR EPREUVE ----------- //
		// ------------------------------------------ //
		/** Affichage d'une épreuve en fonction d'un id
		 * @return : Affichage les informations de l'épreuve dans la console
		 */
		//epreuveController.displayDetailEpreuveByIdWithoutDetails();
		//epreuveController.displayDetailEpreuveByIdWithDetails();
		
		// ------------------------------------------ //
		// ----------- CONTROLEUR MATCH ----------- //
		// ------------------------------------------ //
		//matchController.displayDetailMatchById();
		//matchController.declareMatchGreenById();
		//matchController.createMatch();
		//matchController.deleteMatchById();
		
		// ---------------------------------------- //
		// ----------- CONTROLEUR SCORE ----------- //
		// ---------------------------------------- //
		scoreController.deleteMatchById();
	}
	
}
